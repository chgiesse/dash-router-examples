from flash import hooks, Input, Output, ctx, Patch
from dash import dcc
import plotly.io as pio
import typing as _t

class ThemeTemplate(dcc.Store):
    _id: _t.ClassVar[str] = "theme-template-store"

    def __init__(self):
        super().__init__(id=self._id, data=None, storage_type='local')

theme_template = ThemeTemplate()

def setup_theme(
    theme_attr_name: str = 'data-mantine-color-scheme',
    light_bg: str = 'rgb(245, 247, 248)',
    dark_bg: str = '#0b0f16',
    bg_css_var: str = '--mantine-color-body',
):

    theme_index_str = f"""
        <!-- Theme-detection script runs as early as possible to avoid flash -->
        <script>
            (function() {{
                try {{
                    function applyMantineScheme(scheme) {{
                        document.documentElement.setAttribute('{theme_attr_name}', scheme);
                        var bg = scheme === 'dark' ? '{dark_bg}' : '{light_bg}';
                        document.documentElement.style.setProperty('{bg_css_var}', bg);
                        document.documentElement.style.colorScheme = scheme;
                    }}

                    var stored = null;
                    try {{
                        stored = window.localStorage && window.localStorage.getItem('{theme_template._id}');
                    }} catch (e) {{
                        stored = null;
                    }}

                    var mq = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
                    var systemPrefersDark = mq ? mq.matches : false;

                    var initialScheme = stored || (systemPrefersDark ? 'dark' : 'light');
                    applyMantineScheme(initialScheme);

                    if (mq && mq.addEventListener) {{
                        mq.addEventListener('change', function(e) {{
                            try {{
                                var hasStored = window.localStorage && window.localStorage.getItem('theme_template._id');
                                if (!hasStored) {{
                                    applyMantineScheme(e.matches ? 'dark' : 'light');
                                }}
                            }} catch (err) {{
                                // fail silently
                            }}
                        }});
                    }} else if (mq && mq.addListener) {{
                        // older browsers
                        mq.addListener(function(e) {{
                            try {{
                                var hasStored = window.localStorage && window.localStorage.getItem('{theme_template._id}');
                                if (!hasStored) {{
                                    applyMantineScheme(e.matches ? 'dark' : 'light');
                                }}
                            }} catch (err) {{}}
                        }});
                    }}

                    window.setMantineScheme = function(scheme) {{
                        try {{
                            if (window.localStorage) {{
                                window.localStorage.setItem('mantine-color-scheme', scheme);
                            }}
                        }} catch (e) {{}}
                        applyMantineScheme(scheme);
                    }};
                }} catch (e) {{
                    // fail silently — app still works
                }}
            }})();
        </script>
    """

    @hooks.index(priority=1)
    def add_theme_index(index: str) -> str:
        return index.replace('<head>', f'<head>{theme_index_str}', 1)

def create_theme_callback(figure_id):
    @hooks.callback(
        Output(figure_id, "figure"),
        Input("color-scheme-toggle", "checked"),
        prevent_initial_call=True,
    )
    def apply_theme(theme):
        template = (
            pio.templates["plotly_dark"] if theme is True else pio.templates["plotly"]
        )
        def create_patch():
            patched_fig = Patch()
            patched_fig["layout"]["template"] = template
            return patched_fig

        if isinstance(ctx.outputs_list, list):
            return [create_patch() for _ in ctx.outputs_list]

        return create_patch()

vizro_dark = {
    "layout": {
        "annotationdefaults": {
            "font": {"size": 14, "color": "rgba(255, 255, 255, 0.8784313725)"},
            "showarrow": False,
        },
        "bargroupgap": 0.1,
        "coloraxis": {
            "autocolorscale": False,
            "colorbar": {
                "outlinewidth": 0,
                "showticklabels": True,
                "thickness": 20,
                "tickfont": {"size": 14, "color": "rgba(255, 255, 255, 0.6)"},
                "ticklabelposition": "outside",
                "ticklen": 8,
                "ticks": "outside",
                "tickwidth": 1,
                "title": {"font": {"size": 14, "color": "rgba(255, 255, 255, 0.6)"}},
                "tickcolor": "rgba(255, 255, 255, 0.3019607843)",
            },
        },
        "colorscale": {
            "diverging": [
                [0.0, "#7e000c"],
                [0.05555555555555555, "#9d1021"],
                [0.1111111111111111, "#bc1f37"],
                [0.16666666666666666, "#db2f4c"],
                [0.2222222222222222, "#ea536b"],
                [0.2777777777777778, "#f67486"],
                [0.3333333333333333, "#fe94a0"],
                [0.3888888888888889, "#fbb6be"],
                [0.4444444444444444, "#f8d6da"],
                [0.5, "#E6E8EA"],
                [0.5555555555555556, "#afe7f9"],
                [0.6111111111111112, "#5bd6fe"],
                [0.6666666666666666, "#3bbef1"],
                [0.7222222222222222, "#24a6e1"],
                [0.7777777777777778, "#0d8ed1"],
                [0.8333333333333334, "#0077bd"],
                [0.8888888888888888, "#0061a4"],
                [0.9444444444444444, "#004c8c"],
                [1.0, "#003875"],
            ],
            "sequential": [
                [0.0, "#afe7f9"],
                [0.125, "#5bd6fe"],
                [0.25, "#3bbef1"],
                [0.375, "#24a6e1"],
                [0.5, "#0d8ed1"],
                [0.625, "#0077bd"],
                [0.75, "#0061a4"],
                [0.875, "#004c8c"],
                [1.0, "#003875"],
            ],
            "sequentialminus": [
                [0.0, "#7e000c"],
                [0.125, "#9d1021"],
                [0.25, "#bc1f37"],
                [0.375, "#db2f4c"],
                [0.5, "#ea536b"],
                [0.625, "#f67486"],
                [0.75, "#fe94a0"],
                [0.875, "#fbb6be"],
                [1.0, "#f8d6da"],
            ],
        },
        "colorway": [
            "#00b4ff",
            "#ff9222",
            "#3949ab",
            "#ff5267",
            "#08bdba",
            "#fdc935",
            "#689f38",
            "#976fd1",
            "#f781bf",
            "#52733e",
        ],
        "font": {
            "family": "Inter, sans-serif, Arial",
            "size": 14,
            "color": "rgba(255, 255, 255, 0.8784313725)",
        },
        "legend": {
            "bgcolor": "rgba(0, 0, 0, 0)",
            "font": {"size": 14, "color": "rgba(255, 255, 255, 0.8784313725)"},
            "orientation": "h",
            "title": {
                "font": {"size": 14, "color": "rgba(255, 255, 255, 0.8784313725)"}
            },
            "y": -0.2,
        },
        "map": {"style": "carto-darkmatter"},
        "margin": {"autoexpand": True, "b": 64, "l": 80, "pad": 0, "r": 24, "t": 64},
        "modebar": {
            "activecolor": "darkgrey",
            "bgcolor": "rgba(0, 0, 0, 0)",
            "color": "dimgrey",
        },
        "showlegend": True,
        "title": {
            "font": {"size": 20, "color": "rgba(255, 255, 255, 0.8784313725)"},
            "pad": {"b": 0, "l": 24, "r": 24, "t": 24},
            "x": 0,
            "xanchor": "left",
            "xref": "container",
            "y": 1,
            "yanchor": "top",
            "yref": "container",
        },
        "uniformtext": {"minsize": 12, "mode": "hide"},
        "xaxis": {
            "automargin": True,
            "layer": "below traces",
            "linewidth": 1,
            "showline": True,
            "showticklabels": True,
            "tickfont": {"size": 14, "color": "rgba(255, 255, 255, 0.6)"},
            "ticklabelposition": "outside",
            "ticklen": 8,
            "ticks": "outside",
            "tickwidth": 1,
            "title": {
                "font": {"size": 16, "color": "rgba(255, 255, 255, 0.8784313725)"},
                "standoff": 8,
            },
            "visible": True,
            "zeroline": False,
            "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
            "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            "tickcolor": "rgba(255, 255, 255, 0.3019607843)",
        },
        "yaxis": {
            "automargin": True,
            "layer": "below traces",
            "linewidth": 1,
            "showline": False,
            "showticklabels": True,
            "tickfont": {"size": 14, "color": "rgba(255, 255, 255, 0.6)"},
            "ticklabelposition": "outside",
            "ticklen": 8,
            "ticks": "outside",
            "tickwidth": 1,
            "title": {
                "font": {"size": 16, "color": "rgba(255, 255, 255, 0.8784313725)"},
                "standoff": 8,
            },
            "visible": True,
            "zeroline": False,
            "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
            "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            "tickcolor": "rgba(255, 255, 255, 0.3019607843)",
        },
        "geo": {"bgcolor": "#141721", "lakecolor": "#141721", "landcolor": "#141721"},
        "paper_bgcolor": "#141721",
        "plot_bgcolor": "#141721",
        "polar": {
            "angularaxis": {
                "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
                "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            },
            "bgcolor": "#141721",
            "radialaxis": {
                "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
                "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            },
        },
        "ternary": {
            "aaxis": {
                "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
                "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            },
            "baxis": {
                "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
                "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            },
            "bgcolor": "#141721",
            "caxis": {
                "gridcolor": "rgba(255, 255, 255, 0.1019607843)",
                "linecolor": "rgba(255, 255, 255, 0.3019607843)",
            },
        },
    },
    "data": {
        "bar": [{"marker": {"line": {"color": "#141721"}}, "type": "bar"}],
        "waterfall": [
            {
                "connector": {
                    "line": {"color": "rgba(255, 255, 255, 0.3019607843)", "width": 1}
                },
                "decreasing": {"marker": {"color": "#ff9222"}},
                "increasing": {"marker": {"color": "#00b4ff"}},
                "textfont": {"color": "rgba(255, 255, 255, 0.8784313725)"},
                "textposition": "outside",
                "totals": {"marker": {"color": "grey"}},
                "type": "waterfall",
            }
        ],
    },
}

vizro_light = {
    "layout": {
        "annotationdefaults": {
            "font": {"size": 14, "color": "rgba(20, 23, 33, 0.8784313725)"},
            "showarrow": False,
        },
        "bargroupgap": 0.1,
        "coloraxis": {
            "autocolorscale": False,
            "colorbar": {
                "outlinewidth": 0,
                "showticklabels": True,
                "thickness": 20,
                "tickfont": {"size": 14, "color": "rgba(20, 23, 33, 0.6)"},
                "ticklabelposition": "outside",
                "ticklen": 8,
                "ticks": "outside",
                "tickwidth": 1,
                "title": {"font": {"size": 14, "color": "rgba(20, 23, 33, 0.6)"}},
                "tickcolor": "rgba(20, 23, 33, 0.3019607843)",
            },
        },
        "colorscale": {
            "diverging": [
                [0.0, "#7e000c"],
                [0.05555555555555555, "#9d1021"],
                [0.1111111111111111, "#bc1f37"],
                [0.16666666666666666, "#db2f4c"],
                [0.2222222222222222, "#ea536b"],
                [0.2777777777777778, "#f67486"],
                [0.3333333333333333, "#fe94a0"],
                [0.3888888888888889, "#fbb6be"],
                [0.4444444444444444, "#f8d6da"],
                [0.5, "#E6E8EA"],
                [0.5555555555555556, "#afe7f9"],
                [0.6111111111111112, "#5bd6fe"],
                [0.6666666666666666, "#3bbef1"],
                [0.7222222222222222, "#24a6e1"],
                [0.7777777777777778, "#0d8ed1"],
                [0.8333333333333334, "#0077bd"],
                [0.8888888888888888, "#0061a4"],
                [0.9444444444444444, "#004c8c"],
                [1.0, "#003875"],
            ],
            "sequential": [
                [0.0, "#afe7f9"],
                [0.125, "#5bd6fe"],
                [0.25, "#3bbef1"],
                [0.375, "#24a6e1"],
                [0.5, "#0d8ed1"],
                [0.625, "#0077bd"],
                [0.75, "#0061a4"],
                [0.875, "#004c8c"],
                [1.0, "#003875"],
            ],
            "sequentialminus": [
                [0.0, "#7e000c"],
                [0.125, "#9d1021"],
                [0.25, "#bc1f37"],
                [0.375, "#db2f4c"],
                [0.5, "#ea536b"],
                [0.625, "#f67486"],
                [0.75, "#fe94a0"],
                [0.875, "#fbb6be"],
                [1.0, "#f8d6da"],
            ],
        },
        "colorway": [
            "#00b4ff",
            "#ff9222",
            "#3949ab",
            "#ff5267",
            "#08bdba",
            "#fdc935",
            "#689f38",
            "#976fd1",
            "#f781bf",
            "#52733e",
        ],
        "font": {
            "family": "Inter, sans-serif, Arial",
            "size": 14,
            "color": "rgba(20, 23, 33, 0.8784313725)",
        },
        "legend": {
            "bgcolor": "rgba(0, 0, 0, 0)",
            "font": {"size": 14, "color": "rgba(20, 23, 33, 0.8784313725)"},
            "orientation": "h",
            "title": {"font": {"size": 14, "color": "rgba(20, 23, 33, 0.8784313725)"}},
            "y": -0.2,
        },
        "map": {"style": "carto-darkmatter"},
        "margin": {"autoexpand": True, "b": 64, "l": 80, "pad": 0, "r": 24, "t": 64},
        "modebar": {
            "activecolor": "darkgrey",
            "bgcolor": "rgba(0, 0, 0, 0)",
            "color": "dimgrey",
        },
        "showlegend": True,
        "title": {
            "font": {"size": 20, "color": "rgba(20, 23, 33, 0.8784313725)"},
            "pad": {"b": 0, "l": 24, "r": 24, "t": 24},
            "x": 0,
            "xanchor": "left",
            "xref": "container",
            "y": 1,
            "yanchor": "top",
            "yref": "container",
        },
        "uniformtext": {"minsize": 12, "mode": "hide"},
        "xaxis": {
            "automargin": True,
            "layer": "below traces",
            "linewidth": 1,
            "showline": True,
            "showticklabels": True,
            "tickfont": {"size": 14, "color": "rgba(20, 23, 33, 0.6)"},
            "ticklabelposition": "outside",
            "ticklen": 8,
            "ticks": "outside",
            "tickwidth": 1,
            "title": {
                "font": {"size": 16, "color": "rgba(20, 23, 33, 0.8784313725)"},
                "standoff": 8,
            },
            "visible": True,
            "zeroline": False,
            "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
            "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            "tickcolor": "rgba(20, 23, 33, 0.3019607843)",
        },
        "yaxis": {
            "automargin": True,
            "layer": "below traces",
            "linewidth": 1,
            "showline": False,
            "showticklabels": True,
            "tickfont": {"size": 14, "color": "rgba(20, 23, 33, 0.6)"},
            "ticklabelposition": "outside",
            "ticklen": 8,
            "ticks": "outside",
            "tickwidth": 1,
            "title": {
                "font": {"size": 16, "color": "rgba(20, 23, 33, 0.8784313725)"},
                "standoff": 8,
            },
            "visible": True,
            "zeroline": False,
            "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
            "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            "tickcolor": "rgba(20, 23, 33, 0.3019607843)",
        },
        "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "white"},
        "paper_bgcolor": "white",
        "plot_bgcolor": "white",
        "polar": {
            "angularaxis": {
                "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
                "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            },
            "bgcolor": "white",
            "radialaxis": {
                "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
                "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            },
        },
        "ternary": {
            "aaxis": {
                "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
                "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            },
            "baxis": {
                "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
                "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            },
            "bgcolor": "white",
            "caxis": {
                "gridcolor": "rgba(20, 23, 33, 0.1019607843)",
                "linecolor": "rgba(20, 23, 33, 0.3019607843)",
            },
        },
    },
    "data": {
        "bar": [{"marker": {"line": {"color": "white"}}, "type": "bar"}],
        "waterfall": [
            {
                "connector": {
                    "line": {"color": "rgba(20, 23, 33, 0.3019607843)", "width": 1}
                },
                "decreasing": {"marker": {"color": "#ff9222"}},
                "increasing": {"marker": {"color": "#00b4ff"}},
                "textfont": {"color": "rgba(20, 23, 33, 0.8784313725)"},
                "textposition": "outside",
                "totals": {"marker": {"color": "grey"}},
                "type": "waterfall",
            }
        ],
    },
}

def apply_vizro_theme():
    pio.templates["plotly_dark"] = vizro_dark
    pio.templates["plotly"] = vizro_light
