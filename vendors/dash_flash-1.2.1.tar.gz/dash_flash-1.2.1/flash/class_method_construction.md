I want to make callbacks compatible with class methods so that:

```python
from flash import Input, Output, html, callback, set_props
class MyComponent(html.Div):

    class ids:
        output = 'output'
        btn = 'btn'

    @classmethod
    def set_loading(cls):
        set_props(cls.ids.btn, {"disabled": True})

    @callback(
        Output(ids.output, "children"),
        Input(ids.btn, "n_clicks", "n_clicks")
    )
    @classmethod
    def my_callback(cls, n_clicks):
        cls.set_loading()
        set_props(cls.ids.output, {"bg", "red"})
        return "Updated"

    @callback(Input(ids.btn, "n_clicks"))
    def normal_callback(n_clicks):
        pass
```

While not classmethod callbacks should also still work!!
Keep the solution as simple as possible 
